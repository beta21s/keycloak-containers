import{m as o}from"./assets/module.esm-62c37d0d.js";window.Alpine=o;o.start();
